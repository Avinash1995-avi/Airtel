"""firstapp URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
# from app.views import ProductList, ProductDetail, ProductCreate, ProductDelete, ProductUpdate
from django.contrib.auth import views as auth_views

#imports added for displaying images
from django.conf import settings
from django.conf.urls.static import static
from app import views 

#imports for API
from rest_framework import routers
from app.views import AirtelView, AirtelList, DG, LT, Home
from django.urls import path, include


#rest framemwork
from rest_framework.authtoken import views as token_views

#Router
router = routers.DefaultRouter()
router.register('', AirtelView)


urlpatterns = [
    path('prodapi/', include(router.urls)),
    path('api-token-auth/', token_views.obtain_auth_token, name='api-token-auth'), # Added for rest permission
    path('admin/', admin.site.urls),
    path('param/', AirtelList.as_view(), name='airtel_list'),
    path('', Home.as_view(), name='home'),
    path('dg/', DG.as_view(), name='dg'),
    path('lt/', LT.as_view(), name='lt'),
    # path('home/', views.home, name='home'),
    # path('product_detail/', ProductDetail.as_view(), name='product_detail'),
    # path('product_create/', ProductCreate.as_view(), name='product_create'),
    # path('product_delete/<int:pk>', ProductDelete.as_view(), name='product_delete'),
    # path('product_update/<int:pk>', ProductUpdate.as_view(), name='product_update'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout', kwargs={'template_name': 'app/login.html'}),
    

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) #settings added for displahying images

