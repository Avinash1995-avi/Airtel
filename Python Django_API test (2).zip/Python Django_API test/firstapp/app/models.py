from django.db import models
from django.urls import reverse
from django_cryptography.fields import encrypt

class AirtelDevice(models.Model):
    name = models.CharField(max_length=200)
    voltage = models.DecimalField(max_digits=7, decimal_places=2)
    current = models.DecimalField(max_digits=7, decimal_places=2)
    energy = models.DecimalField(max_digits=7, decimal_places=2)
    powerfactor = models.DecimalField(max_digits=7, decimal_places=2)
    frequency = models.DecimalField(max_digits=7, decimal_places=2)
    count = models.IntegerField(default=0)
    device_image = models.ImageField(upload_to="", default='Nothing')

    def __str__(self):
        return self.name


