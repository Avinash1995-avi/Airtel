from django import forms
from app.models import Product

class ProductForm(forms.ModelForm):
    image = forms.ImageField(required=False)

    class Meta:
        model = Product
        fields = ('name', 'image', 'price', 'rating', 'address')

        widgets = {
            'name' : forms.TextInput(attrs= {'class' : 'textinputclass'}),
            'address' : forms.Textarea(attrs={'class': 'editable medium-editor-textarea postcontent'}),
            'price': forms.TextInput(attrs= {'class' : 'textinputclass'}),
            'rating': forms.TextInput(attrs= {'class' : 'textinputclass'}),

        }