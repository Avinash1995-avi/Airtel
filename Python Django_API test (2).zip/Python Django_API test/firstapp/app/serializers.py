from rest_framework import serializers
from app.models import AirtelDevice

class AirtelSerializer(serializers.HyperlinkedModelSerializer):
    class Meta():
        model = AirtelDevice
        fields = ('name','voltage','frequency','powerfactor','device_image','energy','current')

