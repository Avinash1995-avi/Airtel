from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView, DeleteView, UpdateView, TemplateView
from app.models import AirtelDevice
from django.urls import reverse_lazy

#Imports for api
from rest_framework import viewsets
from app.serializers import AirtelSerializer


#API Serializer viwsets
class AirtelView(viewsets.ModelViewSet):
    queryset = AirtelDevice.objects.all()
    serializer_class = AirtelSerializer


class AirtelList(ListView):
    model = AirtelDevice

    def get_queryset(self):
        return AirtelDevice.objects.filter().order_by('id')

class DG(TemplateView):
    template_name= 'app/dg_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['device'] = AirtelDevice.objects.all()
        return context

class LT(TemplateView):
    template_name= 'app/lt_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['device'] = AirtelDevice.objects.all()
        return context

class Home(TemplateView):
    template_name= 'app/home.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['device'] = AirtelDevice.objects.all()
        return context
    

# #Trying matplotlib
# import matplotlib
# matplotlib.use('Agg')
# import matplotlib.pyplot as plt
# import io
# import urllib, base64
# from urllib.request import urlopen
# import json
# import pandas as pd
# import plotly.express as px

# def home(request):
#     plt.plot(range(10))
#     fig = plt.gcf()

#     buf = io.BytesIO()
#     fig.savefig(buf, format='png')
#     buf.seek(0)
#     string = base64.b64encode(buf.read())
#     uri = urllib.parse.quote(string)
#     return render(request, 'app/home.html', {'data':uri})

 